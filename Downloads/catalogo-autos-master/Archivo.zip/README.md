# Catálogo de autos

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Scripts disponibles

En el directorio del proyecto, puedes ejecutar:

### `npm start`

Ejecuta la aplicación en modo de desarrollo.\
Abrí [http://localhost:3000](http://localhost:3000) para verla en el navegador.

La página se recargará si haces modificaciones.
También verás cualquier error de lint en la consola.

### `npm test`

Corre el test runner en modo interactivo.

### `npm run build`

Compila la aplicación para producción en la carpeta: `build`.\
Empaqueta correctamente React en modo de producción y optimiza la compilación para el mejor rendimiento.